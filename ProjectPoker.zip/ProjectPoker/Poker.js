


// This game will be quite simple as it's just you vs the Dealer 

console.log(" Welcome to three card Poker || The rules are explained below") // Introduction to Poker // This is the back-end code 
console.log("The aim of Three cards is to make the best poker hand possible with three cards");
console.log("You must compare your hand against the dealer's hand");

let choice; // Will allow the player to make a choice on what to play 

// The first thing we will need is the random number generator for RNG

let playercard1 = Math.floor(Math.random() * 11) + 1; // This will be the players three cards 
let playercard2 = Math.floor(Math.random() * 11) + 1;
let playercard3 = Math.floor(Math.random() * 11) + 1;



let dealercard1 = Math.floor(Math.random() * 11) + 1;
let dealercard2 = Math.floor(Math.random() * 11) + 1; // There are four varations of cards such as Spades, Hearts, Diamonds and club 
let dealercard3 = Math.floor(Math.random() * 11) + 1; // There are also Kings, Queens and Jacks 

// Now we need to make an array of Cards in Poker // Based on the random numbers we get we will pull a random card 
// Array will hold the deck of 52 cards

let playerCardtype = Math.floor(Math.random() * 4) + 1; // Card types will decide || Spades || Hearts || Diamonds || Clubs || Queens || Jacks || Queens 
let playerCardtype2 = Math.floor(Math.random() * 4) + 1; 
let playerCardype3 = Math.floor(Math.random() * 4) + 1; 

let DealerCardtype = Math.floor(Math.random() * 4) + 1; 
let DealerCardtype2 = Math.floor(Math.random() * 4) + 1; 
let DealerCardtype3 = Math.floor(Math.random() * 4) + 1; 

let spades   = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; 
let hearts   = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
let diamonds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
let club     = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
 
let playertotal = playercard1 + playercard2 + playercard3;  // Will be the total of Players card
let dealertotal = dealercard1 + dealercard2 + dealercard3;  // Will be the total of Dealers card 

function Placebet(){

}

function PickCards(playercard1, playercard2, playercard3, dealercard1, dealercard2, dealercard3, spades, diamonds, hearts, club,
 playerCardtype, playerCardtype2, playerCardtype3, DealerCardtype, DealerCardtype2, DealerCardtype3 // Pass paremters inside function 
 ){  
    if(playercard1 == 1 || playercard1 == 2 || playercard1 == 3 || playercard1  == 4 || playercard1 == 5 || playercard1 
     == 6 || playercard1 == 7 || playercard1 == 8 || playercard1 == 9 || playercard1 == 10 || playercard1 == 11){
    // A random number will choose what type of poker card to be displayed later
    if(playerCardtype == 1 || playerCardtype == 2 || playerCardtype == 3 || playerCardtype == 4){ 
        if(playerCardtype == 1){ // A random number will choose what type of poker card to be displayed later
            console.log("A Spades card will be picked");
        }else if(playerCardtype == 2){
            console.log("A clubs card will be choosen");
        }else if(playerCardtype == 3){
            console.log("A hearts card will be picked");
        }else if(playerCardtype == 4){
            console.log("A diamonds card will be picked");
        }
     }
    }
     if(playercard2 == 1 || playercard2 == 2 || playercard2 == 3 || playercard2  == 4 || playercard2 == 5 || playercard2 
     == 6 || playercard2 == 7 || playercard2 == 8 || playercard2 == 9 || playercard2 == 10 || playercard2 == 11){
       console.log("Players Second card was " + playercard2);
       // A random number will choose what type of poker card to be displayed later
       if(playerCardtype2 == 1 || playerCardtype2 == 2 || playerCardtype2 == 2 || playerCardtype2 == 4){ 
        if(playerCardtype2 == 1){ 
            console.log("A Spades card will be picked");
        }else if(playerCardtype2 == 2){
            console.log("A clubs card will be choosen");
        }else if(playerCardtype2 == 3){
            console.log("A hearts card will be picked");
        }else if(playerCardtype2 == 4){
            console.log("A diamonds card will be picked");
       }
     }
    }
     if(playercard3 == 1 || playercard3 == 2 || playercard3 == 3 || playercard3  == 4 || playercard3 == 5 || playercard3 
     == 6 || playercard3 == 7 || playercard3 == 8 || playercard3 == 9 || playercard3 == 10 || playercard3 == 11){
        console.log("Players third card was a " + playercard3);
        // A random number will choose what type of poker card to be displayed later
        if(playerCardype3 == 1 || playerCardtype3 == 2 || playerCardtype3 == 3 || playerCardtype3 == 4){ 
        if(playerCardtype3 == 1){ // A random number will choose what type of poker card to be displayed later
            console.log("A Spades card will be picked");
        }else if(playerCardtype3 == 2){
            console.log("A clubs card will be choosen");
        }else if(playerCardtype3 == 3){
            console.log("A hearts card will be picked");
        }else if(playerCardtype3 == 4){
            console.log("A diamonds card will be picked");
       }
     }

    }
     if(dealercard1 == 1 || dealercard1 == 2 || dealercard1 == 3 || dealercard1 == 4 || dealercard1 == 5 || dealercard1 == 6 ||
        dealercard1 == 7 || dealercard1 == 8 || dealercard1 == 9 || dealercard1 == 10 || dealercard1 == 11){
        console.log("Dealer first card was " + dealercard1);
        // A random number will choose what type of poker card to be displayed later
        if(DealerCardtype == 1 || DealerCardtype == 2 || DealerCardtype == 3 || DealerCardtype == 4){
            if(DealerCardtype == 1){ // A random number will choose what type of poker card to be displayed later
            console.log("A Spades card will be picked");
            }else if(DealerCardtype == 2){
            console.log("A clubs card will be choosen");
            }else if(DealerCardtype == 3){
            console.log("A hearts card will be picked");
            }else if(DealerCardtype == 4){
            console.log("A diamonds card will be picked");
        }
        
     }
     
    }
     if(dealercard2 == 1 || dealercard2 == 2 || dealercard2 == 3 || dealercard2 == 4 || dealercard2 == 5 || dealercard2 == 6 ||
        dealercard2 == 7 || dealercard2 == 8 || dealercard2 == 9 || dealercard2 == 10 || dealercard2 == 11){
        console.log("Dealer's second card is " + dealercard2);
        // A random number will choose what type of poker card to be displayed later
         if(DealerCardtype2 == 1 || DealerCardtype2 == 2 || DealerCardtype2 == 3 || DealerCardtype2 == 4){
            if(DealerCardtype2 == 1){ // A random number will choose what type of poker card to be displayed later
            console.log("A Spades card will be picked");
            }else if(DealerCardtype2 == 2){
            console.log("A clubs card will be choosen");
            }else if(DealerCardtype2 == 3){
            console.log("A hearts card will be picked");
            }else if(DealerCardtype2 == 4){
            console.log("A diamonds card will be picked");    
        }

     }
    }
     if(dealercard3 == 1 || dealercard3 == 2 || dealercard3 == 3 || dealercard3 == 4 || dealercard3 == 5 || dealercard3 == 6 ||
        dealercard3 == 7 || dealercard3 == 8 || dealercard3 == 9 || dealercard3 == 10 || dealercard3 == 11){
        console.log("Dealers third card was  " + dealercard3);
        // A random number will choose what type of poker card to be displayed later
         if(DealerCardtype3 == 1 || DealerCardtype3 == 2 || DealerCardtype3 == 3 || DealerCardtype3 == 4){
            if(DealerCardtype3 == 1){ // A random number will choose what type of poker card to be displayed later
            console.log("A Spades card will be picked");
            }else if(DealerCardtype3 == 2){
            console.log("A clubs card will be choosen");
            }else if(DealerCardtype3 == 3){
            console.log("A hearts card will be picked");
            }else if(DealerCardtype3 == 4){
            console.log("A diamonds card will be picked");
         }
  }

 }

}

PickCards(playercard1, playercard2, playercard3, dealercard1, dealercard2, dealercard3, spades, diamonds, hearts, club, 
 playerCardtype, playerCardtype2, playerCardype3, DealerCardtype, DealerCardtype2, DealerCardtype3);


function DisplayCards(playercard1, playercard2, playercard3, playerCardtype, playerCardtype2, playerCardtype3, dealercard1, dealercard2, DealerCardtype3
    ,DealerCardtype, DealerCardtype2, DealerCardtype3){ // The parameters here 
    // To conduct this function we will need event listners
    console.log("Your Cards: ", playercard1,  playercard2, playercard3); // We need to decide what cards display based on RNG with if statements 


    let displaycard1 = document.getElementById("HiddenCards5");  // Images will change when button is pressed 
    if(displaycard1.src.match('card-back-face.jpg')){
        displaycard1.src = 'Ace.png'
    }
    else
    {
        displaycard1.src = 'HiddenCards0'
    }



    console.log(" Dealers Cards are hidden for now");
}


 DisplayCards(playercard1, playercard2, playercard3,dealercard1, dealercard2, DealerCardtype3
    ,DealerCardtype, DealerCardtype2, DealerCardtype3 )// Passing The argument 

// These two functions will decide where the game goes based on player decesion 


switch(choice){ // This switch case will allow you to make a decesion based off the cards 

case 1:
function Fold(){
}
break;

case 2:
function Play(){
}
break;
default:
console.log("Not an option sir");
break;
}


function ScoreBoard(){ // Scoreboard not decided yet 

}


